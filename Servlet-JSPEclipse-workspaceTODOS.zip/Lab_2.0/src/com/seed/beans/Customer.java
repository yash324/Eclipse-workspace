package com.seed.beans;

public class Customer {
	private long mobile;
	private int pincode;
	private String name;
	
//	TODO:1	Provide no-argument public constructor
//	TODO:2	Provide getters and setters for all attributes.
}
